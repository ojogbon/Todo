-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 02, 2019 at 01:43 PM
-- Server version: 5.6.38
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `todo`
--

-- --------------------------------------------------------

--
-- Table structure for table `do_todo`
--

CREATE TABLE `do_todo` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `spec` varchar(20) NOT NULL,
  `task` mediumtext NOT NULL,
  `state` varchar(111) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `do_todo`
--

INSERT INTO `do_todo` (`id`, `userid`, `spec`, `task`, `state`, `date`, `status`) VALUES
(1, 0, '0.2461656439573663oc', 'good deal', '', '2019-06-02 13:32:49', 'delete'),
(2, 0, '0.15936030803255785o', 'how far', '', '2019-06-02 13:32:47', 'delete'),
(3, 0, '0.1891074365234129oc', 'very well', '', '2019-06-02 13:32:51', 'delete'),
(4, 0, '0.21632268268591304o', 'last file', 'done', '2019-06-02 13:33:52', '0'),
(5, 0, '0.8429041880902319oc', 'really cool', 'done', '2019-06-02 13:33:57', '0'),
(6, 0, '0.8370504634822136oc', 'cool like', '', '2019-06-02 13:33:40', '0'),
(7, 0, '0.26055017262669167o', 'fine shine', '', '2019-06-02 13:34:41', '0');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(111) NOT NULL,
  `password` varchar(111) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `date`, `status`) VALUES
(1, 'segunlade', 'password', '2019-06-01 22:58:56', '0'),
(2, 'tadelola', '78786', '2019-06-02 05:31:10', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `do_todo`
--
ALTER TABLE `do_todo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `do_todo`
--
ALTER TABLE `do_todo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
